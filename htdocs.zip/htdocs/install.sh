#!/data/data/com.termux/files/usr/bin/bash

clear
echo "🔥 INSTALLING PISO WIFI MULTI-AREA + MACRO SYSTEM..."

set -e

# ================= INSTALL =================
pkg update -y && pkg upgrade -y
pkg install php git tmux iproute2 -y

# ================= CLEAN =================
echo "🧹 Cleaning old install..."
rm -rf ~/htdocs ~/tempwifi

# ================= CLONE =================
echo "📥 Downloading system..."
git clone https://github.com/alpisowifi-ops/voucher_via_gcash.git ~/tempwifi || {
    echo "❌ CLONE FAILED! Check internet."
    exit 1
}

# ================= CREATE HTDOCS =================
mkdir -p ~/htdocs
cd ~/htdocs

# ================= GET IP =================
IP=$(ip route get 1 2>/dev/null | awk '{print $7;exit}')
[ -z "$IP" ] && IP="127.0.0.1"

# ================= CREATE AREAS =================
echo "📁 Creating areas..."

MACRO_LIST=""

for AREA in area1 area2
do
    echo "➡️ Setting up $AREA..."

    cp -r ~/tempwifi $AREA
    cd $AREA

    # 🔐 FIXED API NAME (mas madali sa MacroDroid)
    API_NAME="api.php"

    # 🔑 UNIQUE KEY PER AREA
    SECRET_KEY=$(tr -dc a-z0-9 </dev/urandom | head -c 10)

    # 🔁 RENAME API
    if [ -f "d6s0or.php" ]; then
        mv d6s0or.php $API_NAME
    fi

    # 🔑 SET KEY
    sed -i "s/u36qbe29fl/$SECRET_KEY/g" $API_NAME || true

    # 📝 SET AREA NAME SA CONFIG
    sed -i "s/PISO WIFI/$(echo $AREA | tr a-z A-Z)/g" config.json || true

    # 📱 SAVE MACRO LINK
    MACRO_LIST="$MACRO_LIST\n👉 $AREA:\nhttp://$IP:8080/$AREA/$API_NAME?amount=10&key=$SECRET_KEY\n"

    cd ..
done

# REMOVE TEMP
rm -rf ~/tempwifi

# ================= START SERVER =================
echo "🚀 Starting server..."

cat > ~/start_wifi.sh <<EOF
cd ~/htdocs
php -S 0.0.0.0:8080
EOF

chmod +x ~/start_wifi.sh

tmux kill-session -t wifi 2>/dev/null || true
tmux new-session -d -s wifi "~/start_wifi.sh"

# ================= DONE =================
echo ""
echo "✅ INSTALL COMPLETE!"
echo ""

echo "🌐 ACCESS:"
echo "👉 AREA1: http://$IP:8080/area1"
echo "👉 AREA2: http://$IP:8080/area2"
echo ""

echo "🔐 ADMIN:"
echo "👉 http://$IP:8080/area1/admin.php"
echo "👉 http://$IP:8080/area2/admin.php"
echo "👉 Password: admin123"
echo ""

echo "📱 MACRODROID LINKS:"
echo -e "$MACRO_LIST"

echo "⚡ Server running in background (tmux)"